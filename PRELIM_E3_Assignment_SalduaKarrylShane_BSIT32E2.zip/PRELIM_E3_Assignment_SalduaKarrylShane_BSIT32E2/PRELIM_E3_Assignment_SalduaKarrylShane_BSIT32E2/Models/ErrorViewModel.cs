namespace PRELIM_E3_Assignment_SalduaKarrylShane_BSIT32E2.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
